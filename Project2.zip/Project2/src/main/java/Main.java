import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
	static final int sceneWidth = 1280;
	static final int sceneHeight = 720;

	private Scene scene;
	private StackPane rootPane;
	private BlackjackUI blackjackUI;

	@Override
	public void start(Stage primaryStage) {
		// TODO Auto-generated method stub

		rootPane = new StackPane();
		rootPane.setBackground(Background.fill(Color.web("#0F2128")));

		blackjackUI = new BlackjackUI(rootPane);
		blackjackUI.startUI(); // blackJackGame object instantiates when start button is triggered in blackJackUI

		scene = new Scene(rootPane , sceneWidth,sceneHeight);

		primaryStage.setScene(scene);
		primaryStage.setTitle("Haider Alzoubi Project 2");
		primaryStage.setResizable(false); // change if you want, but keep false so the screen doesnt look weird
		primaryStage.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
}
