import java.util.ArrayList;
import java.util.Random;

public class BlackjackDealer {

    private ArrayList<Card> deck;


    public BlackjackDealer(){
        //printDeck();
    }

    /*
    This should generate 52 cards, one for each of
    13 faces and 4 suits

    11 = J
    12 = Q
    13 = K
     */
    public void generateDeck(){
        deck = new ArrayList<>();
        String[] allPossibleSuits = {"Heart", "Spade", "Diamond", "Club"};

        for(int i = 0; i < allPossibleSuits.length; i++) {
            for(int j = 1; j <= 13; j++) {
                deck.add(new Card(allPossibleSuits[i], j));
            }
        }
    }

    /*
    This will return an Arraylist of two cards
    and leave the remainder of the deck able to be drawn later
     */
    public ArrayList<Card> dealHand() {
        ArrayList<Card> hand = new ArrayList<>();

        if (deck.size() >= 2) {
            for (int i = 0; i < 2; i++) {
                int index = (int) (Math.random() * deck.size());
                hand.add(deck.remove(index));
            }
        }
        else {
            System.out.println("Not enough cards in deck");

            return null;
        }

        return hand;
    }

    /*
     This will return the next card on top of the deck
     */
    public Card drawOne(){
        if (!deck.isEmpty()) {
            return deck.remove(0);
        }
        else {
            System.out.println("Deck is empty");

            return null;
        }
    }

    /*
    This will return all 52 cards to the deck and
    shuffle their order
     */
    public void shuffleDeck() {
        generateDeck();

        Random random = new Random();

        for (int i = deck.size() - 1; i > 0; i--) {
            int indexToSwap = random.nextInt(i + 1);

            Card temp = deck.get(indexToSwap);

            deck.set(indexToSwap, deck.get(i));
            deck.set(i, temp);
        }

        System.out.println("SHUFFLED CARDS");
    }

    /*
    This will return the number of cards left in the deck.
    After a call to shuffleDeck() this should be 52
     */
    public int deckSize(){
        return deck.size();
    }

    private void printDeck(){
        for(int i = 0; i < deck.size(); i++) {
            System.out.println(deck.get(i).getValue() + " " + deck.get(i).getSuit() + " ");
        }
    }

    public ArrayList<Card> getDeck() {
        return deck;
    }
}
