import java.util.ArrayList;

public class BlackjackGame {

    private ArrayList<Card> playerHand;
    private ArrayList<Card> bankerHand;
    private BlackjackDealer theDealer;
    private BlackjackGameLogic gameLogic;

    // The amount currently bet from the user
    private double currentBet;
    // The total amount of value that the user has
    private double totalWinnings;

    public BlackjackGame(){
        theDealer = new BlackjackDealer();
        theDealer.shuffleDeck();

        gameLogic = new BlackjackGameLogic();

        playerHand = theDealer.dealHand();
        bankerHand = theDealer.dealHand();
    }

    // deals new hands
    public void nextRound(){
        playerHand = theDealer.dealHand();
        bankerHand = theDealer.dealHand();
    }

    /*
    This method will determine if the user
    won or lost their bet and return the amount won or lost based on the value in
    currentBet
     */
    public double evaluateWinnings() {
        String result = gameLogic.whoWon(playerHand, bankerHand);

        double winnings = 0;

        boolean playerBlackjack = gameLogic.handTotal(playerHand) == 21 && playerHand.size() == 2;
        boolean dealerBlackjack = gameLogic.handTotal(bankerHand) == 21 && bankerHand.size() == 2;

        if (playerBlackjack && !dealerBlackjack) {
            winnings = currentBet * 1.5;
        }
        else if (dealerBlackjack && !playerBlackjack) {
            winnings = -currentBet;
        }
        else if (result.equals("Dealer")) {
            winnings = -currentBet;
        }
        else if (result.equals("Player")) {
            winnings = currentBet;
        }
        else if (result.equals("Push")) {
            winnings = 0;
        }

        return winnings;
    }

    public void setTotalWinnings(double totalWinnings) {
        this.totalWinnings = totalWinnings;
    }

    public void setCurrentBet(double currentBet){
        if(currentBet >= 0) {
            this.currentBet = currentBet;
        }
        else{
            this.currentBet = 0;
        }
    }

    public double getTotalWinnings() {
        return totalWinnings;
    }

    public double getCurrentBet() {
        return currentBet;
    }

    public BlackjackDealer getTheDealer() {
        return theDealer;
    }

    public ArrayList<Card> getBankerHand() {
        return bankerHand;
    }

    public ArrayList<Card> getPlayerHand() {
        return playerHand;
    }

    public BlackjackGameLogic getGameLogic() {
        return gameLogic;
    }
}
