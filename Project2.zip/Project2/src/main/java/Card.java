public class Card {
    private String suit;
    private int value;

    public Card(String theSuit, int theValue){
        suit = theSuit;
        value = theValue;
    }

    public int getValue() {
        return value;
    }

    public String getSuit() {
        return suit;
    }
}
