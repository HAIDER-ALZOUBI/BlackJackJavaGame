import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.TextAlignment;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class BlackjackUI {

    private StackPane paneRoot;
    private BlackjackGame blackjackGame;

    Font montFont = Font.loadFont(getClass().getResourceAsStream("/fonts/Montserrat-ExtraBold.ttf"), 40);
    Font montIttalicFont = Font.loadFont(getClass().getResourceAsStream("/fonts/Montserrat-ExtraBoldItalic.ttf"), 14);

    public BlackjackUI(StackPane paneRoot){
        this.paneRoot = paneRoot;
    }

    public void startUI(){
        drawHomeScreen();
    }

    private void drawHomeScreen(){
        // Background
        Image image = ImageCache.getImage("/backgrounds/home_screen.png");
        ImagePattern imagePattern = new ImagePattern(image);

        // invalidText
        Text invalidText = new Text("You Need To Insert More Than 0$: Value Has To Be A Positive Number");
        invalidText.setFill(Color.RED);
        invalidText.setFont(montIttalicFont);
        invalidText.setVisible(false);
        StackPane.setAlignment(invalidText, Pos.CENTER);
        StackPane.setMargin(invalidText, new javafx.geometry.Insets(125, 0, 0, 0));

        // startAmountTextField
        TextField startAmountTextField = new TextField();
        startAmountTextField.setPromptText("Starting Amount");
        startAmountTextField.setStyle("-fx-prompt-text-fill: derive(-fx-control-inner-background, -30%); -fx-font-size: 14px; -fx-border-color: #aaa; -fx-border-radius: 5px;");
        startAmountTextField.setMaxHeight(50);
        startAmountTextField.setMaxWidth(200);
        StackPane.setAlignment(startAmountTextField, Pos.CENTER);
        StackPane.setMargin(startAmountTextField, new javafx.geometry.Insets(-50, 0, 0, 0));

        // startButton
        Button startButton = new Button("Start");
        startButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;");
        startButton.setOnMousePressed(e -> startButton.setStyle("-fx-background-color: #8c2425; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        startButton.setOnMouseReleased(e -> startButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        startButton.setFont(montFont);
        StackPane.setAlignment(startButton, Pos.CENTER);
        StackPane.setMargin(startButton, new javafx.geometry.Insets(50, 0, 0, 0));

        // pane
        paneRoot.getChildren().addAll(startAmountTextField, startButton, invalidText);
        paneRoot.setBackground(Background.fill(imagePattern));

        // startButton action
        startButton.setOnAction(e -> {
            if(Double.parseDouble(startAmountTextField.getText()) <= 0.0) {
                invalidText.setText("Invalid Money Amount: Should be a positive number.");
                invalidText.setVisible(true);
            }
            else{
                blackjackGame = new BlackjackGame();
                blackjackGame.setTotalWinnings(Double.parseDouble(startAmountTextField.getText()));
                blackjackGame.setCurrentBet(0);
                paneRoot.getChildren().clear();
                drawBettingScreen();
            }
        });
    }

    private void drawBettingScreen(){
        // Background
        Image image = ImageCache.getImage("/backgrounds/betting_screen.png");
        ImagePattern imagePattern = new ImagePattern(image);

        // betButton
        Button betButton = new Button("Bet");
        betButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;");
        betButton.setFont(montFont);
        betButton.setOnMousePressed(e -> betButton.setStyle("-fx-background-color: #792021; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        betButton.setOnMouseReleased(e -> betButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        StackPane.setAlignment(betButton, Pos.CENTER);
        StackPane.setMargin(betButton, new javafx.geometry.Insets(40, 0, 0, 0));

        // betMoneyText
        Text betMoneyText = new Text("$" + blackjackGame.getCurrentBet());
        betMoneyText.setFill(Color.WHITE);
        betMoneyText.setFont(montFont);
        StackPane.setAlignment(betMoneyText, Pos.CENTER);
        StackPane.setMargin(betMoneyText, new javafx.geometry.Insets(0, 0, 40, 0));

        // bankText
        Text bankText = new Text("Bank: $" + blackjackGame.getTotalWinnings());
        bankText.setFill(Color.web("#0F2128"));
        bankText.setFont(montFont);
        bankText.setTextAlignment(TextAlignment.LEFT);
        StackPane.setAlignment(bankText, Pos.TOP_LEFT);
        StackPane.setMargin(bankText, new javafx.geometry.Insets(380, 0, 0, 80));

        // invalidText
        Text invalidText = new Text("Not Enough Money In Bank To Add That Amount:\nChoose a smaller value or just bet current amount");
        invalidText.setFill(Color.RED);
        invalidText.setFont(montIttalicFont);
        invalidText.setVisible(false);
        StackPane.setAlignment(invalidText, Pos.CENTER);
        StackPane.setMargin(invalidText, new javafx.geometry.Insets(125, 0, 0, 0));

        // bet1Button
        Button bet1Button = new Button("$1");
        bet1Button.setMaxSize(50, 50);
        bet1Button.setStyle("-fx-background-color: #868686; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet1Button.setFont(montFont);
        bet1Button.setOnMousePressed(e -> bet1Button.setStyle("-fx-background-color: #686868; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet1Button.setOnMouseReleased(e -> bet1Button.setStyle("-fx-background-color: #868686; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet1Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet1Button, new javafx.geometry.Insets(510, 0, 0, 120));

        // bet5Button
        Button bet5Button = new Button("$5");
        bet5Button.setMaxSize(50, 50);
        bet5Button.setStyle("-fx-background-color: #ff0000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet5Button.setFont(montFont);
        bet5Button.setOnMousePressed(e -> bet5Button.setStyle("-fx-background-color: #cc0000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet5Button.setOnMouseReleased(e -> bet5Button.setStyle("-fx-background-color: #ff0000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet5Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet5Button, new javafx.geometry.Insets(510, 0, 0, 220));

        // bet10Button
        Button bet10Button = new Button("$10");
        bet10Button.setMaxSize(50, 50);
        bet10Button.setStyle("-fx-background-color: #22ff00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet10Button.setFont(montFont);
        bet10Button.setOnMousePressed(e -> bet10Button.setStyle("-fx-background-color: #00cc00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet10Button.setOnMouseReleased(e -> bet10Button.setStyle("-fx-background-color: #22ff00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet10Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet10Button, new javafx.geometry.Insets(510, 0, 0, 320));

        // bet25Button
        Button bet25Button = new Button("$25");
        bet25Button.setMaxSize(50, 50);
        bet25Button.setStyle("-fx-background-color: #0015ff; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet25Button.setFont(montFont);
        bet25Button.setOnMousePressed(e -> bet25Button.setStyle("-fx-background-color: #0000cc; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet25Button.setOnMouseReleased(e -> bet25Button.setStyle("-fx-background-color: #0015ff; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet25Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet25Button, new javafx.geometry.Insets(510, 0, 0, 420));

        // bet100Button
        Button bet100Button = new Button("$100");
        bet100Button.setMaxSize(50, 50);
        bet100Button.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet100Button.setFont(montFont);
        bet100Button.setOnMousePressed(e -> bet100Button.setStyle("-fx-background-color: #333333; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet100Button.setOnMouseReleased(e -> bet100Button.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet100Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet100Button, new javafx.geometry.Insets(510, 0, 0, 520));

        // bet500Button
        Button bet500Button = new Button("$500");
        bet500Button.setMaxSize(50, 50);
        bet500Button.setStyle("-fx-background-color: #b700ff; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet500Button.setFont(montFont);
        bet500Button.setOnMousePressed(e -> bet500Button.setStyle("-fx-background-color: #9900cc; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet500Button.setOnMouseReleased(e -> bet500Button.setStyle("-fx-background-color: #b700ff; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet500Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet500Button, new javafx.geometry.Insets(510, 0, 0, 620));

        // bet1000Button
        Button bet1000Button = new Button("$1000");
        bet1000Button.setMaxSize(100, 100);
        bet1000Button.setStyle("-fx-background-color: #ffcc00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet1000Button.setFont(montFont);
        bet1000Button.setOnMousePressed(e -> bet1000Button.setStyle("-fx-background-color: #cc9900; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet1000Button.setOnMouseReleased(e -> bet1000Button.setStyle("-fx-background-color: #ffcc00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet1000Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet1000Button, new javafx.geometry.Insets(590, 0, 0, 120));

        // bet5000Button
        Button bet5000Button = new Button("$5000");
        bet5000Button.setMaxSize(100, 100);
        bet5000Button.setStyle("-fx-background-color: #ff4d00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        bet5000Button.setFont(montFont);
        bet5000Button.setOnMousePressed(e -> bet5000Button.setStyle("-fx-background-color: #cc3300; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        bet5000Button.setOnMouseReleased(e -> bet5000Button.setStyle("-fx-background-color: #ff4d00; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(bet5000Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet5000Button, new javafx.geometry.Insets(590, 0, 0, 320));

        // bet10000Button
        Button bet10000Button = new Button("$10000");
        bet10000Button.setMaxSize(100, 100);
        bet10000Button.setStyle("-fx-background-color: #ffffff; -fx-text-fill: #000000; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px; -fx-border-color: #000000;");
        bet10000Button.setFont(montFont);
        bet10000Button.setOnMousePressed(e -> bet10000Button.setStyle("-fx-background-color: #e6e6e6; -fx-text-fill: #000000; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px; -fx-border-color: #000000;"));
        bet10000Button.setOnMouseReleased(e -> bet10000Button.setStyle("-fx-background-color: #ffffff; -fx-text-fill: #000000; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px; -fx-border-color: #000000;"));
        StackPane.setAlignment(bet10000Button, Pos.TOP_LEFT);
        StackPane.setMargin(bet10000Button, new javafx.geometry.Insets(590, 0, 0, 520));

        // betAllButton
        Button betAllButton = new Button("All In");
        betAllButton.setMaxSize(100, 50);
        betAllButton.setStyle("-fx-background-color: #0f2128; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;");
        betAllButton.setFont(montFont);
        betAllButton.setOnMousePressed(e -> betAllButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        betAllButton.setOnMouseReleased(e -> betAllButton.setStyle("-fx-background-color: #0f2128; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 20px;"));
        StackPane.setAlignment(betAllButton, Pos.TOP_LEFT);
        StackPane.setMargin(betAllButton, new javafx.geometry.Insets(430, 0, 0, 120));

        paneRoot.getChildren().addAll(betButton, betMoneyText, bankText, invalidText, bet1Button, bet5Button, bet10Button, bet25Button,
                bet100Button, bet500Button, bet1000Button, bet5000Button, bet10000Button, betAllButton);
        paneRoot.setBackground(Background.fill(imagePattern));

        betButton.setOnAction(e -> {
            if(blackjackGame.getCurrentBet() > 0.0){
                paneRoot.getChildren().clear();

                if(blackjackGame.getTheDealer().deckSize() <= 10){
                    blackjackGame.getTheDealer().shuffleDeck();
                }

                drawRoundScreen();
            }
            else{
                invalidText.setText("Not Enough: You Need To Bet More Than $0");
                invalidText.setVisible(true);
            }
        });

        bet1Button.setOnAction(e -> {
            int value = 1;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet5Button.setOnAction(e -> {
            int value = 5;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet10Button.setOnAction(e -> {
            int value = 10;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet25Button.setOnAction(e -> {
            int value = 25;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet100Button.setOnAction(e -> {
            int value = 100;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet500Button.setOnAction(e -> {
            int value = 500;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet1000Button.setOnAction(e -> {
            int value = 1000;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet5000Button.setOnAction(e -> {
            int value = 5000;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        bet10000Button.setOnAction(e -> {
            int value = 10000;

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });

        betAllButton.setOnAction(e -> {
            double value = blackjackGame.getTotalWinnings();

            betSelectedAmount(betMoneyText, bankText, invalidText, value);
        });
    }

    private void drawRoundScreen(){
        // Background
        Image image = ImageCache.getImage("/backgrounds/round_screen.png");
        ImagePattern imagePattern = new ImagePattern(image);

        // invalidText
        Text invalidText = new Text("You Need To Insert More Than 0$: Value Has To Be A Positive Number");
        invalidText.setFill(Color.RED);
        invalidText.setFont(montIttalicFont);
        invalidText.setVisible(false);
        StackPane.setAlignment(invalidText, Pos.CENTER);
        StackPane.setMargin(invalidText, new javafx.geometry.Insets(125, 0, 0, 0));

        // bankText
        Text bankText = new Text("Bank: $" + blackjackGame.getTotalWinnings());
        bankText.setFill(Color.web("#0F2128"));
        bankText.setFont(montFont);
        bankText.setTextAlignment(TextAlignment.LEFT);
        StackPane.setAlignment(bankText, Pos.TOP_LEFT);
        StackPane.setMargin(bankText, new javafx.geometry.Insets(658, 0, 0, 46));

        // betMoneyText
        Text betMoneyText = new Text("Bet: $" + blackjackGame.getCurrentBet());
        betMoneyText.setFill(Color.web("#0F2128"));
        betMoneyText.setFont(montFont);
        betMoneyText.setTextAlignment(TextAlignment.LEFT);
        StackPane.setAlignment(betMoneyText, Pos.TOP_LEFT);
        StackPane.setMargin(betMoneyText, new javafx.geometry.Insets(658, 0, 0, 950));

        // hitButton
        Button hitButton = new Button("Hit");
        hitButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;");
        hitButton.setOnMousePressed(e -> hitButton.setStyle("-fx-background-color: #8c2425; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        hitButton.setOnMouseReleased(e -> hitButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        hitButton.setFont(montFont);
        hitButton.setMaxSize(80, 50);
        StackPane.setAlignment(hitButton, Pos.CENTER);
        StackPane.setMargin(hitButton, new javafx.geometry.Insets(100, 250, 0, 0));

        // standButton
        Button standButton = new Button("Stand");
        standButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;");
        standButton.setOnMousePressed(e -> standButton.setStyle("-fx-background-color: #8c2425; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        standButton.setOnMouseReleased(e -> standButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        standButton.setFont(montFont);
        standButton.setMaxSize(80, 50);
        StackPane.setAlignment(standButton, Pos.CENTER);
        StackPane.setMargin(standButton, new javafx.geometry.Insets(100, -250, 0, 0));

        // Cards count and panes
        StackPane playerCardsPane = new StackPane();
        AtomicInteger playerCardCount = new AtomicInteger(0);
        StackPane dealerCardsPane = new StackPane();
        AtomicInteger dealerCardCount = new AtomicInteger(0);

        // Draw Player Cards
        drawPlayerCard(playerCardCount, 100 * playerCardCount.get(), 380, playerCardsPane, true);
        drawPlayerCard(playerCardCount, 100 * playerCardCount.get(), 380, playerCardsPane, true);

        // Draw Dealer Cards
        drawDealerCard(dealerCardCount, 100 * dealerCardCount.get(), -178, dealerCardsPane, true);
        Rectangle hiddenCard = drawHiddenCard(dealerCardCount, 100 * dealerCardCount.get(), -178, dealerCardsPane);

        // playerScoreText
        Text playerScoreText = new Text("Player\n" + blackjackGame.getGameLogic().handTotal(blackjackGame.getPlayerHand()));
        playerScoreText.setFill(Color.web("#FFFFFF"));
        playerScoreText.setFont(montFont);
        playerScoreText.setTextAlignment(TextAlignment.CENTER);
        StackPane.setAlignment(playerScoreText, Pos.CENTER);
        StackPane.setMargin(playerScoreText, new javafx.geometry.Insets(380, 0, 0, 575));

        // hiddenCardValue
        ArrayList<Card> hiddenCardHand = new ArrayList<>(blackjackGame.getBankerHand());
        hiddenCardHand.remove(hiddenCardHand.size() - 1);

        // dealerScoreText
        Text dealerScoreText = new Text("Dealer\n" + ((blackjackGame.getGameLogic().handTotal(hiddenCardHand))));
        dealerScoreText.setFill(Color.web("#FFFFFF"));
        dealerScoreText.setFont(montFont);
        dealerScoreText.setTextAlignment(TextAlignment.CENTER);
        StackPane.setAlignment(dealerScoreText, Pos.CENTER);
        StackPane.setMargin(dealerScoreText, new javafx.geometry.Insets(-178, 0, 0, 575));

        // pane
        paneRoot.getChildren().addAll(playerCardsPane, dealerCardsPane, hitButton, standButton, invalidText, bankText, betMoneyText, playerScoreText, dealerScoreText);
        paneRoot.setBackground(Background.fill(imagePattern));

        // hitButton action
        hitButton.setOnAction(e -> {
            double playerCardXOffset = 100;
            double playerCardX = (playerCardXOffset * playerCardCount.get());
            double playerCardY = 380;

            drawPlayerCard(playerCardCount, playerCardX, playerCardY, playerCardsPane, false);
            playerScoreText.setText("Player\n" + blackjackGame.getGameLogic().handTotal(blackjackGame.getPlayerHand()));

            if(blackjackGame.getGameLogic().handTotal(blackjackGame.getPlayerHand()) >= 21) {
                standButton.fire();
            }
        });

        // standButton action
        standButton.setOnAction(e -> {
            double dealerCardXOffset = 100;
            double dealerCardX = (dealerCardXOffset * dealerCardCount.get());
            double dealerCardY = -178;

            setHiddenCard(dealerCardCount, dealerCardX, dealerCardY, dealerCardsPane, hiddenCard);

            while(blackjackGame.getGameLogic().evaluateBankerDraw(blackjackGame.getBankerHand())){
                dealerCardX = (dealerCardXOffset * dealerCardCount.get());
                drawDealerCard(dealerCardCount, dealerCardX, dealerCardY, dealerCardsPane, false);
            }

            dealerScoreText.setText("Dealer\n" + blackjackGame.getGameLogic().handTotal(blackjackGame.getBankerHand()));

            standButton.setDisable(true);
            hitButton.setDisable(true);

            boolean playerBlackjack = (blackjackGame.getGameLogic().handTotal(blackjackGame.getPlayerHand()) == 21) && (blackjackGame.getPlayerHand().size() == 2);
            boolean dealerBlackjack = (blackjackGame.getGameLogic().handTotal(blackjackGame.getBankerHand()) == 21) && (blackjackGame.getBankerHand().size() == 2);

            checkWin(playerBlackjack, dealerBlackjack);
        });

        if((blackjackGame.getGameLogic().handTotal(blackjackGame.getPlayerHand()) == 21) && (blackjackGame.getPlayerHand().size() == 2)) {
            standButton.fire();
        }
    }

    private void checkWin(boolean isPlayerBlackJack, boolean isDealerBlackJack) {
        String whoWon = blackjackGame.getGameLogic().whoWon(blackjackGame.getPlayerHand(), blackjackGame.getBankerHand());
        System.out.println("Winning = " + blackjackGame.evaluateWinnings());

        if(Objects.equals(whoWon, "Player")){
            drawPlayerRoundResult(whoWon, isPlayerBlackJack, isDealerBlackJack);
        }
        else if(Objects.equals(whoWon, "Dealer")){
            drawPlayerRoundResult(whoWon, isPlayerBlackJack, isDealerBlackJack);
        }
        else{
            drawPlayerRoundResult(whoWon, isPlayerBlackJack, isDealerBlackJack);
        }
    }

    private void drawPlayerRoundResult(String result, boolean isPlayerBlackJack, boolean isDealerBlackJack){
        // winText
        Text winText = new Text();
        winText.setFill(Color.RED);
        winText.setFont(montIttalicFont);
        StackPane.setAlignment(winText, Pos.CENTER);
        StackPane.setMargin(winText, new javafx.geometry.Insets(125, 0, 0, 0));

        if (Objects.equals(result, "Player") && isPlayerBlackJack) {
            winText.setText("Player BLACKJACK!");
        }
        else if (Objects.equals(result, "Dealer") && isDealerBlackJack) {
            winText.setText("Dealer BLACKJACK!");
        }
        else if (Objects.equals(result, "Player")) {
            winText.setText("Player Won!");
        }
        else if(Objects.equals(result, "Dealer")) {
            winText.setText("Dealer Won!");
        }
        else {
            winText.setText("Push!");
        }

        // conintueButton
        Button conintueButton = new Button("Continue");
        conintueButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;");
        conintueButton.setOnMousePressed(e -> conintueButton.setStyle("-fx-background-color: #8c2425; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        conintueButton.setOnMouseReleased(e -> conintueButton.setStyle("-fx-background-color: #F74244; -fx-text-fill: white; -fx-font-size: 14px; -fx-border-radius: 5px; -fx-background-radius: 5px;"));
        conintueButton.setFont(montFont);
        StackPane.setAlignment(conintueButton, Pos.CENTER);
        StackPane.setMargin(conintueButton, new javafx.geometry.Insets(60, 0, 0, 0));

        // pane
        paneRoot.getChildren().addAll(conintueButton, winText);

        // conintueButton action
        conintueButton.setOnAction(e -> {
            paneRoot.getChildren().clear();

            if(Objects.equals(result, "Player")){
                blackjackGame.setTotalWinnings(blackjackGame.getTotalWinnings()  + blackjackGame.getCurrentBet() + blackjackGame.evaluateWinnings());

                blackjackGame.setCurrentBet(0);
                blackjackGame.nextRound();

                drawBettingScreen();
            }
            else if(Objects.equals(result, "Dealer")){
                if(blackjackGame.getTotalWinnings() <= 0.0 || blackjackGame.getTotalWinnings() +  blackjackGame.evaluateWinnings() + blackjackGame.getCurrentBet() <= 0){
                    blackjackGame = null;

                    drawHomeScreen();
                }
                else{
                    blackjackGame.setTotalWinnings(blackjackGame.getTotalWinnings() + blackjackGame.getCurrentBet() + blackjackGame.evaluateWinnings());

                    blackjackGame.setCurrentBet(0);
                    blackjackGame.nextRound();

                    drawBettingScreen();
                }
            }
            else{
                blackjackGame.setTotalWinnings(blackjackGame.getTotalWinnings() + blackjackGame.getCurrentBet());
                blackjackGame.setCurrentBet(0);

                blackjackGame.nextRound();

                drawBettingScreen();
            }
        });
    }

    private void drawPlayerCard(AtomicInteger playerCardCount, double playerCardX, double playerCardY, StackPane playerCardsPane, boolean isStartingCard){
        Card card = null;

        if(isStartingCard){
            card = blackjackGame.getPlayerHand().get(playerCardCount.get());
        }
        else {
            card = blackjackGame.getTheDealer().drawOne();
            blackjackGame.getPlayerHand().add(card);
        }

        Rectangle playerCard = drawCard(card, playerCardX, playerCardY);
        playerCardCount.getAndIncrement();

        playerCardsPane.getChildren().addAll(playerCard);
        playerCardsPane.setTranslateX(-playerCardX / 4);
    }

    private void drawDealerCard(AtomicInteger dealerCardCount, double dealerCardX, double dealerCardY, StackPane dealerCardsPane, boolean isStartingCard){
        Card card;

        if(isStartingCard){
            card = blackjackGame.getBankerHand().get(dealerCardCount.get());
        }
        else {
            card = blackjackGame.getTheDealer().drawOne();
            blackjackGame.getBankerHand().add(card);
        }

        Rectangle dealerCard = drawCard(card, dealerCardX, dealerCardY);
        dealerCardCount.getAndIncrement();

        dealerCardsPane.getChildren().addAll(dealerCard);
        dealerCardsPane.setTranslateX(-dealerCardX / 4);
    }

    private Rectangle drawHiddenCard(AtomicInteger dealerCardCount, double dealerCardX, double dealerCardY, StackPane dealerCardsPane){
        Rectangle hiddenCard = drawCard(null, dealerCardX, dealerCardY);

        dealerCardsPane.getChildren().addAll(hiddenCard);
        dealerCardsPane.setTranslateX(-dealerCardX / 4);

        return hiddenCard;
    }

    private void setHiddenCard(AtomicInteger dealerCardCount, double dealerCardX, double dealerCardY, StackPane dealerCardsPane, Rectangle hiddenCard){
        Card card = blackjackGame.getBankerHand().get(dealerCardCount.get());
        dealerCardCount.getAndIncrement();

        Rectangle newCard = drawCard(card, dealerCardX, dealerCardY);

        dealerCardsPane.getChildren().remove(hiddenCard);
        dealerCardsPane.getChildren().addAll(newCard);
    }

    private Rectangle drawCard(Card card, double x, double y){
        Rectangle cardRectangle = new Rectangle();
        cardRectangle.setWidth(125);
        cardRectangle.setHeight(175);
        cardRectangle.setStroke(Color.BLACK);
        cardRectangle.setStrokeWidth(0.5);
        StackPane.setAlignment(cardRectangle, Pos.CENTER);
        StackPane.setMargin(cardRectangle, new javafx.geometry.Insets(y, 0, 0, x));

        setCardImage(card, cardRectangle);

        return cardRectangle;
    }

    private void setCardImage(Card card, Rectangle cardRectangle){
        String fileName;

        if(card == null){
            fileName = "HiddenCard";
        }
        else {
            fileName = getCardFileName(card);
        }

        Image image = ImageCache.getImage("/cards/" + fileName + ".png");
        ImagePattern imagePattern = new ImagePattern(image);

        //System.out.println("/cards/" + fileName + ".png");

        cardRectangle.setFill(imagePattern);
    }

    private String getCardFileName(Card card) {
        int value = card.getValue();
        String suit = card.getSuit();

        String fileName = "";

        if (value == 1) {
            fileName += "A";
        }
        else if (value == 11) {
            fileName += "J";
        }
        else if (value == 12) {
            fileName += "Q";
        }
        else if (value == 13) {
            fileName += "K";
        }
        else {
            fileName += value;
        }

        fileName += "_" + suit;

        return fileName;
    }

    private void betSelectedAmount(Text betMoneyText, Text bankText, Text invalidText, double value) {
        if(blackjackGame.getTotalWinnings() - value < 0.0 || blackjackGame.getTotalWinnings() <= 0.0){
            //System.out.println("Not enough money to bet");
            invalidText.setVisible(true);
        }
        else {
            blackjackGame.setTotalWinnings(blackjackGame.getTotalWinnings() - value);
            blackjackGame.setCurrentBet(blackjackGame.getCurrentBet() + value);
            betMoneyText.setText("$" + blackjackGame.getCurrentBet());
            bankText.setText("Bank: $" + blackjackGame.getTotalWinnings());
            invalidText.setVisible(false);
        }
    }
}
