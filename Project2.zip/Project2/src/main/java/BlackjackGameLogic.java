import java.util.ArrayList;

public class BlackjackGameLogic {

    public BlackjackGameLogic(){

    }

    /*
    Given two hands this should return either player or dealer or push depending
    on who wins
     */
    public String whoWon(ArrayList<Card> playerHand, ArrayList<Card> dealerHand) {
        int playerTotal = handTotal(playerHand);
        int dealerTotal = handTotal(dealerHand);

        if (playerTotal > 21) {
            return "Dealer";
        }
        else if (dealerTotal > 21) {
            return "Player";
        }
        else if (playerTotal > dealerTotal) {
            return "Player";
        }
        else if (dealerTotal > playerTotal) {
            return "Dealer";
        }
        else {
            return "Push"; // draw
        }
    }

    /*
    This should return the total
    value of all cards in the hand
     */
    public int handTotal(ArrayList<Card> hand) {
        int total = 0;
        int aceCount = 0;

        for (int i = 0; i < hand.size(); i++) {
            int value = hand.get(i).getValue();

            if (value >= 10) {
                total += 10;
            }
            else if (value == 1) {
                aceCount++;
                total += 11;
            }
            else {
                total += value;
            }
        }

        while (total > 21 && aceCount > 0) {
            total -= 10;
            aceCount--;
        }

        return total;
    }

    /*
    This method should return true if the dealer should
    draw another card, i.e. if the value is 16 or less.
     */
    public boolean evaluateBankerDraw(ArrayList<Card> hand){
        return handTotal(hand) <= 16;
    }
}

