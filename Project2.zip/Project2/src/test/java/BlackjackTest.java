import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;

class BlackjackTest {

	private BlackjackGame game;

	@Test
	public void testCardCreation() {
		Card card = new Card("Hearts", 10);
		assertEquals("Hearts", card.getSuit(), "Card suit should be Hearts");
		assertEquals(10, card.getValue(), "Card value should be 10");
	}

	@Test
	public void setUpGame() {
		game = new BlackjackGame();
		game.setCurrentBet(100);
	}

	@Test
	public void testInitialization() {
		game = new BlackjackGame();
		assertNotNull(game.getPlayerHand(), "Player hand shouldnt be null after game initialization");
		assertNotNull(game.getBankerHand(), "Banker hand shouldnt be null after game initialization");
		assertEquals(2, game.getPlayerHand().size(), "Player should have 2 cards after initialization");
		assertEquals(2, game.getBankerHand().size(), "Banker should have 2 cards after initialization");
		assertEquals(48, game.getTheDealer().deckSize(), "Deck should have 48 cards remaining after dealing 2 hands");
	}

	@Test
	public void testDealHandWhenDeckIsEmpty() {
		BlackjackGame game = new BlackjackGame();

		while (game.getTheDealer().deckSize() > 0) {
			game.getTheDealer().drawOne();
		}

		assertNull(game.getTheDealer().dealHand(), "Should return null when want to deal a hand from an empty deck");
	}

	@Test
	public void testValueOfFaceCards() {
		BlackjackGame game = new BlackjackGame();
		ArrayList<Card> faceCards = new ArrayList<>();
		faceCards.add(new Card("Hearts", 11)); // Jack
		faceCards.add(new Card("Spades", 12)); // queen
		faceCards.add(new Card("Diamonds", 13)); // King

		assertEquals(30, game.getGameLogic().handTotal(faceCards), "Face cards should be valued at 10 so all 3 would equal 30");
	}


	@Test
	public void testUniqueCardsInDeck() {
		BlackjackGame game = new BlackjackGame();
		game.getTheDealer().shuffleDeck();

		ArrayList<Card> deck = game.getTheDealer().getDeck();
		assertEquals(52, deck.stream().distinct().count(), "Deck should have 52 unique cards");
	}

	@Test
	public void testBlackjackPayout() {
		game = new BlackjackGame();
		game.setCurrentBet(100);

		ArrayList<Card> blackjackHand = new ArrayList<>();
		blackjackHand.add(new Card("Hearts", 1));
		blackjackHand.add(new Card("Spades", 10));

		game.getPlayerHand().clear();
		game.getPlayerHand().addAll(blackjackHand);

		game.getBankerHand().clear();
		game.getBankerHand().add(new Card("Clubs", 9));
		game.getBankerHand().add(new Card("Diamonds", 7));

		double winnings = game.evaluateWinnings();
		assertEquals(150, winnings, "Winnings should be 1.5x the bet for a blackjack win");
	}

	@Test
	public void testHandValueMultipleAces() {
		BlackjackGame game = new BlackjackGame();
		game.getPlayerHand().clear();
		game.getPlayerHand().add(new Card("Hearts", 1));
		game.getPlayerHand().add(new Card("Spades", 1));
		game.getPlayerHand().add(new Card("Diamonds", 9));
		game.getPlayerHand().add(new Card("Clubs", 6));

		int total = game.getGameLogic().handTotal(game.getPlayerHand());
		assertEquals(17, total, "Hand should use Aces and look for the highest possible total");
	}


	@Test
	public void testNegativeBetting() {
		BlackjackGame game = new BlackjackGame();
		game.setCurrentBet(-100);
		assertEquals(0, game.getCurrentBet(), "negative betting should be return 0");
	}

	@Test
	public void testDealerDrawsUntil17OrHigher() {
		game = new BlackjackGame();
		game.setCurrentBet(100);

		game.getBankerHand().clear();
		game.getBankerHand().add(new Card("Clubs", 2));
		game.getBankerHand().add(new Card("Diamonds", 2));

		while (game.getGameLogic().evaluateBankerDraw(game.getBankerHand())) {
			game.getBankerHand().add(game.getTheDealer().drawOne());
		}

		assertTrue(game.getGameLogic().handTotal(game.getBankerHand()) >= 17, "dealer should keep drawing until reaching at least 17");
	}

	@Test
	public void testPlayerBusts() {
		game = new BlackjackGame();
		game.setCurrentBet(100);
		game.getPlayerHand().clear();
		game.getPlayerHand().add(new Card("Hearts", 10));
		game.getPlayerHand().add(new Card("Spades", 5));
		game.getPlayerHand().add(new Card("Clubs", 7));

		String result = game.getGameLogic().whoWon(game.getPlayerHand(), game.getBankerHand());
		assertEquals("Dealer", result, "Dealer wins if player busts");
	}

	@Test
	public void testDealerDrawsWithAce() {
		game = new BlackjackGame();
		game.getTheDealer().generateDeck();
		game.getTheDealer().shuffleDeck();

		ArrayList<Card> dealerHand = new ArrayList<>();
		dealerHand.add(new Card("Hearts", 1));
		dealerHand.add(new Card("Spades", 6));

		game.getBankerHand().clear();
		game.getBankerHand().addAll(dealerHand);

		boolean shouldDealerDraw = game.getGameLogic().evaluateBankerDraw(game.getBankerHand());

		assertFalse(shouldDealerDraw, "dealer shouldnt draw when holding an Ace and a 6 and should sum to 17");
	}

	@Test
	public void testEmptyDeckOnDeal() {
		game = new BlackjackGame();
		game.setCurrentBet(100);

		while (game.getTheDealer().deckSize() > 2) {
			game.getTheDealer().drawOne();
		}

		assertNotNull(game.getTheDealer().dealHand(), "should be able to deal a hand with just 2 cards left");
		assertNull(game.getTheDealer().dealHand(), "Should not be able to deal a hand with lesss than 2 cards");
	}

	@Test
	public void testAceAdjustmentInPlayerHand() {
		BlackjackGame game = new BlackjackGame();

		game.getPlayerHand().clear();
		game.getPlayerHand().add(new Card("Hearts", 1));
		game.getPlayerHand().add(new Card("Spades", 1));
		game.getPlayerHand().add(new Card("Clubs", 9));

		int total = game.getGameLogic().handTotal(game.getPlayerHand());

		assertEquals(21, total, "Aces should change to get the best possible hand total");
	}

	@Test
	public void testShuffleDeckRestoresFullDeck() {
		BlackjackGame game = new BlackjackGame();

		for (int i = 0; i < 10; i++) {
			game.getTheDealer().drawOne();
		}

		game.getTheDealer().shuffleDeck();
		assertEquals(52, game.getTheDealer().deckSize(), "Shuffling the deck should turn it to a full 52 card deck");
	}

	@Test
	public void testPlayerWinsWithHigherHandThanDealer() {
		BlackjackGame game = new BlackjackGame();

		game.getPlayerHand().clear();
		game.getBankerHand().clear();
		game.getPlayerHand().add(new Card("Hearts", 10));
		game.getPlayerHand().add(new Card("Spades", 9));
		game.getBankerHand().add(new Card("Clubs", 8));
		game.getBankerHand().add(new Card("Diamonds", 8));

		String result = game.getGameLogic().whoWon(game.getPlayerHand(), game.getBankerHand());
		assertEquals("Player", result, "Player should win with a higher totalk that does not go above 21");
	}

	@Test
	public void testPushWhenPlayerAndDealerHaveSameTotal() {
		BlackjackGame game = new BlackjackGame();

		game.getPlayerHand().clear();
		game.getBankerHand().clear();
		game.getPlayerHand().add(new Card("Hearts", 10));
		game.getPlayerHand().add(new Card("Spades", 2));
		game.getBankerHand().add(new Card("Clubs", 9));
		game.getBankerHand().add(new Card("Diamonds", 3));

		String result = game.getGameLogic().whoWon(game.getPlayerHand(), game.getBankerHand());
		assertEquals("Push", result, "Game should end in a push when both player and dealer have the same total");
	}

	@Test
	public void testWinningsAfterWinLosePush() {
		BlackjackGame game = new BlackjackGame();

		double initialWinnings = 1000;

		game.setTotalWinnings(initialWinnings);

		// win
		double currentBet = 100;
		game.setCurrentBet(currentBet);

		double winnings = currentBet;
		game.setTotalWinnings(game.getTotalWinnings() + winnings);
		assertEquals(initialWinnings + winnings, game.getTotalWinnings(), "Total winnings should increase by the bet amount after a win");

		// loss
		game.setTotalWinnings(initialWinnings);
		winnings = -currentBet;
		game.setTotalWinnings(game.getTotalWinnings() + winnings);
		assertEquals(initialWinnings + winnings, game.getTotalWinnings(), "Total winnings should decrease by the bet amount after a loss");

		// push
		game.setTotalWinnings(initialWinnings);
		winnings = 0;
		game.setTotalWinnings(game.getTotalWinnings() + winnings);
		assertEquals(initialWinnings, game.getTotalWinnings(), "Total winnings should stay the same after a push");
	}

	@Test
	public void testNewRoundResetsHandsAndDeck() {
		BlackjackGame game = new BlackjackGame();
		game.nextRound();
		assertTrue(!game.getPlayerHand().isEmpty() && !game.getBankerHand().isEmpty(), "New round should reset hands");
	}

}
